let study = 50 * 60;

let rest = 10 * 60;

let work = true;

let timer;

function start() {

  clearInterval(timer);

  let t = work ? study : rest;

  timer = setInterval(() => {

    let m = Math.floor(t / 60);

    let s = t % 60;

    document.getElementById("time").innerText =

      m + ":" + (s < 10 ? "0" : "") + s;

    t--;

    if (t < 0) {

      work = !work;

      document.getElementById("mode").innerText =

        work ? "Study 📚" : "Break ☕";

      start();

    }

  }, 1000);

}